<?php

function dbConnect()
{
    
    $user = 'root';
    $pass = '';
    $host = 'localhost';
    $dbname ='bowling';
    
    $dsn = "mysql:host=$host;
            dbname=$dbname";
    
    try {
    
    return new PDO($dsn, $user, $pass);
    
    } catch (PDOException $e) {
    echo "Error: ".$e->getMessage();
    exit;
    }
    
}

?>