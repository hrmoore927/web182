<!DOCTYPE html>
<html>
<head>
  <title>New Bowler Team</title>

    <style type="text/css">

      fieldset {
         width: 75%;
         border: 2px solid #cccccc;
      }

      label {
         width: 75px;
         float: left;
         text-align: left;
         font-weight: bold;
      }

      input {
         border: 1px solid #000;
         padding: 3px;
      }

    </style>
</head>

<body>
  <h1>New Bowling Team Entry</h1>

  <form action="insert_bowler_team.php" method="post">

  <fieldset>

    <p><label for="TeamName">Team Name</label>
    <input type="text" id="TeamName" name="TeamName" maxlength="30" size="30" /></p>

   <?php

      
    include 'database/db_conn.php';

    $db = dbConnect();
    $query = "SELECT * from bowlers ORDER BY bowler_id";

        $stmt = $db->prepare($query);
        $stmt->execute();

        echo "<p><label for=\"CaptainID\">Captain ID</label>
        <select id=\"CaptainID\" name=\"CaptainID\">";

            while($result = $stmt->fetch(PDO::FETCH_OBJ)) {
             echo "<option>" .$result->bowler_id . "</option>";    
            }
            
        echo "</select></p>";
        
    ?>
        
  </fieldset>
  
  <p><input type="submit" value="Add New Bowling Team" /></p>
  

  </form>
</body>
</html>
