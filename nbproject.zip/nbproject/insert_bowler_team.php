<!DOCTYPE html>
<html>
<head>
  <title>Bowler Team Entry Results</title>
</head>
<body>
  <h1>Bowler Team Entry Results</h1>
  <?php

    if (!isset($_POST['TeamName']) 
         || !isset($_POST['CaptainID'])) {
       echo "<p>You have not entered all the required details.<br />
             Please go back and try again.</p>";
       exit;
    }

    // create short variable names
    $team_name = $_POST['TeamName'];
    $captain_id = $_POST['CaptainID'];

    @$db = new mysqli('localhost', 'root', '', 'bowling');

    if (mysqli_connect_errno()) {
       echo "<p>Error: Could not connect to database.<br/>
             Please try again later.</p>";
       exit;
    }

    $query = "INSERT INTO teams (team_name, captain_id) VALUES (?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param('si', $team_name, $captain_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo  "<p>Bowler Team inserted into the database.</p>";
    } else {
        echo "<p>An error has occurred.<br/>
              The item was not added.</p>";
    }
  
    $db->close();
  ?>
</body>
</html>
